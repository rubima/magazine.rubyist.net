i = rand(1)
if i == 0
  print "OK: "
  puts i
else
  print "NG: "
  puts i

puts "BYE"
puts "Program END"
