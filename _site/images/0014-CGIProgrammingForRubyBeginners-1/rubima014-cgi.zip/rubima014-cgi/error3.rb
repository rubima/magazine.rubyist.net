print "aaa  bbbb ccccc".to_s(2, " ")
