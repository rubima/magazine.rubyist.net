a = 2
b = rand(3)

if b > a
  puts "b is larger than a."
else
  puts "b is not larger than a."
end
