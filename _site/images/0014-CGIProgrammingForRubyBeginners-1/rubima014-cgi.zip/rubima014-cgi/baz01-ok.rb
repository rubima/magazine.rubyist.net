#!/usr/bin/ruby

print "Content-Type: text/html\n\n"
print "hogehoge"
