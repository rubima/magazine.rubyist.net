a = 2
b = rand(3)

p a, b
puts "-------------------"

if b > a
  p a, b
  puts "b is larger than a."  
else
  p a, b
  puts "b is not larger than a."
end