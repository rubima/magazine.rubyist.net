f = open("erro1.rb")
s = f.read
print s 
f.close 
