print(123)
print("hogehoge" 
print 345
 