priny "hogehoge"
