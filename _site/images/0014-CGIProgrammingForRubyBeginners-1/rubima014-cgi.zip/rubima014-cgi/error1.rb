str = "rubima"
print st
