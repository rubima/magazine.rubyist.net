class CreateTimecardRecord < ActiveRecord::Migration
  def self.up
    @holidays=Holiday.find_all
    @users=User.find_all
    @date_array=[]
    start_date=Date.new(2006,1,1)
    end_date=Date.new(2006,12,31)
    start_date.upto(end_date) do |date|
      @date_array<< date
    end

    for date in @date_array
      for user in @users
        @timecard=user.timecards.build
        @timecard.input_date = date
        if date.wday ==0 || date.wday ==6
          @timecard.workcode_id=5
          @timecard.confirmation_code=2
        else
          @timecard.workcode_id=1
          @timecard.confirmation_code=1
        end
        for holiday in @holidays
          if holiday.holiday_date==date
           @timecard.workcode_id=5
           @timecard.confirmation_code=2
           break
          else
          end
        end
        @timecard.save
      end
    end

  end

  def self.down
  end
end
