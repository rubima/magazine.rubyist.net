class CreateUsers < ActiveRecord::Migration
  def self.up
    create_table :users do |t|
      t.column :password,:string,:limit =>40
      t.column :login,:string,:limit =>80
      t.column :full_name, :string, :limit =>80
      t.column :section_code, :integer,:default =>1
      t.column :position_id, :integer,:default =>1
    end
    User.create(:login =>'rubima',
                :full_name =>'るびま',
                :password =>'rubima')
    User.create(:login =>'perlish',
                :full_name =>'ぱーらー',
                :password =>'perlish',
                :section_code =>2,
                :position_id =>2)
  end

  def self.down
    drop_table :users
  end
end
