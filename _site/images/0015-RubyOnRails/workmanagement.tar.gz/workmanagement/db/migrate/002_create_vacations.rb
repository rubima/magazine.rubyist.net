class CreateVacations < ActiveRecord::Migration
  def self.up
    create_table :vacations do |t|
      t.column :user_id,:integer,:null =>false
      t.column :year,:integer,:limit =>4,:null =>false
      t.column :yearly_vacation,:float
    end
    Vacation.create(:user_id =>1,
                    :year =>2006,
                    :yearly_vacation =>40
                   )
    Vacation.create(:user_id =>2,
                    :year =>2006,
                    :yearly_vacation =>20
                   )
  end

  def self.down
    drop_table :vacations
  end
end
