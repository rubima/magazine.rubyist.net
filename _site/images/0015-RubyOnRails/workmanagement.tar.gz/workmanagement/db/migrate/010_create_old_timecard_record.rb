class CreateOldTimecardRecord < ActiveRecord::Migration
  def self.up
    @holidays=Holiday.find_all
    @users=User.find_all
    @date_array=[]
    start_date=Date.new(2006,1,1)
    end_date=Date.new(2006,12,31)
    start_date.upto(end_date) do |date|
      @date_array<< date
    end

    for date in @date_array
      for user in @users
        @old_timecard=user.old_timecards.build
        @old_timecard.input_date = date
        if date.wday ==0 || date.wday ==6
          @old_timecard.workcode_id=5
          @old_timecard.confirmation_code=2
        else
          @old_timecard.workcode_id=1
          @old_timecard.confirmation_code=1
        end
        for holiday in @holidays
          if holiday.holiday_date==date
           @old_timecard.workcode_id=5
           @old_timecard.confirmation_code=2
           break
          else
          end
        end
        @old_timecard.save
      end
    end

  end

  def self.down
  end
end
