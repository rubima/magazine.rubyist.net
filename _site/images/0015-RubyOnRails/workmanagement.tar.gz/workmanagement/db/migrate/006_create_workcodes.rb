class CreateWorkcodes < ActiveRecord::Migration
  def self.up
    create_table :workcodes do |t|
      t.column :workcode_name,:string
      t.column :use_time,:float
    end
    Workcode.create(:workcode_name =>'入力して下さい')
    Workcode.create(:workcode_name =>'出社')
    Workcode.create(:workcode_name =>'年休',:use_time =>1.0)
    Workcode.create(:workcode_name =>'出張')
    Workcode.create(:workcode_name =>'休日')
  end

  def self.down
    drop_table :workcodes
  end
end
