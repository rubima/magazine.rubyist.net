class CreatePositions < ActiveRecord::Migration
  def self.up
    create_table :positions do |t|
      t.column :position_name, :string
      t.column :work_start_time_h, :integer,:default =>8
      t.column :work_start_time_m, :integer,:default =>30
      t.column :work_end_time_h, :integer,:default =>17
      t.column :work_end_time_m, :integer,:default =>30
    end
    Position.create(:position_name =>'社員',
                    :work_start_time_h => 8,
                    :work_start_time_m => 30,
                    :work_end_time_h => 17,
                    :work_end_time_m => 30)
    Position.create(:position_name =>'バイト',
                    :work_start_time_h => 9,
                    :work_start_time_m => 30,
                    :work_end_time_h => 16,
                    :work_end_time_m => 30)
  end

  def self.down
    drop_table :positions
  end
end
