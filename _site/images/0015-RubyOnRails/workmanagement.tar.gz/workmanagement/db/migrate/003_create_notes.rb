class CreateNotes < ActiveRecord::Migration
  def self.up
    create_table :notes do |t|
      t.column :user_id,:integer,:null =>false
      t.column :year,:integer, :limit =>4,:null =>false
      t.column :month, :integer, :limit =>2,:null =>false
      t.column :comment, :text
    end
  end

  def self.down
    drop_table :notes
  end
end
