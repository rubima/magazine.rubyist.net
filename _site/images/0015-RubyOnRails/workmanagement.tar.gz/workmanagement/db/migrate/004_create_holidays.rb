class CreateHolidays < ActiveRecord::Migration
  def self.up
    create_table :holidays do |t|
      t.column :holiday_date,:date
      t.column :holiday_name, :string,:limit =>50
    end
    Holiday.create(:holiday_date =>'2006-01-01',:holiday_name =>'元旦')
    Holiday.create(:holiday_date =>'2006-01-09',:holiday_name =>'成人の日')
    Holiday.create(:holiday_date =>'2006-02-11',:holiday_name =>'建国記念の日')
    Holiday.create(:holiday_date =>'2006-03-21',:holiday_name =>'春分の日')
    Holiday.create(:holiday_date =>'2006-04-29',:holiday_name =>'みどりの日')
    Holiday.create(:holiday_date =>'2006-05-03',:holiday_name =>'憲法記念日')
    Holiday.create(:holiday_date =>'2006-05-04',:holiday_name =>'国民の休日')
    Holiday.create(:holiday_date =>'2006-05-05',:holiday_name =>'こどもの日')
    Holiday.create(:holiday_date =>'2006-07-17',:holiday_name =>'海の日')
    Holiday.create(:holiday_date =>'2006-09-18',:holiday_name =>'敬老の日')
    Holiday.create(:holiday_date =>'2006-09-23',:holiday_name =>'秋分の日')
    Holiday.create(:holiday_date =>'2006-10-09',:holiday_name =>'体育の日')
    Holiday.create(:holiday_date =>'2006-11-03',:holiday_name =>'文化の日')
    Holiday.create(:holiday_date =>'2006-11-23',:holiday_name =>'勤労感謝の日')
    Holiday.create(:holiday_date =>'2006-12-23',:holiday_name =>'天皇誕生日')
  end

  def self.down
    drop_table :holidays
  end
end
