class CreateOldTimecards < ActiveRecord::Migration
  def self.up
    create_table :old_timecards do |t|
      t.column :input_date,:date
      t.column :user_id,:integer
      t.column :workcode_id,:integer
      t.column :request_date,:date
      t.column :start_time_h, :integer,:default =>0
      t.column :start_time_m, :integer,:default =>0
      t.column :end_time_h, :integer,:default =>0
      t.column :end_time_m, :integer,:default =>0
      t.column :actual_time,:integer,:default =>0
      t.column :card_comment,:string
      t.column :overtime_start_time_h,:integer,:default =>0
      t.column :overtime_start_time_m,:integer,:default =>0
      t.column :overtime_end_time_h,:integer,:default =>0
      t.column :overtime_end_time_m,:integer,:default =>0
      t.column :overtime_total_h,:integer,:default =>0
      t.column :overtime_total_m,:integer,:default =>0
      t.column :overtime_total,:integer,:default =>0
      t.column :updated_at,:datetime
      t.column :confirmation_code,:integer
    end
  end

  def self.down
    drop_table :old_timecards
  end
end
