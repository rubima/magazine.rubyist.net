class Position < ActiveRecord::Base
  has_many :users

  validates_presence_of :position_name
  validates_numericality_of :work_start_time_h,:work_start_time_m,:work_end_time_h,:work_end_time_m
  validates_inclusion_of :work_start_time_h,:work_end_time_h,:in =>0..23
  validates_inclusion_of :work_start_time_m,:work_end_time_m,:in =>0..59
end
