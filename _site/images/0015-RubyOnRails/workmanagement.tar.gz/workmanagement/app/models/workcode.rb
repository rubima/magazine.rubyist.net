class Workcode < ActiveRecord::Base
  has_many :timecards
  has_many :old_timecards
end
