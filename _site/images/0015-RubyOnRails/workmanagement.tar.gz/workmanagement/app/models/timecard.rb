class Timecard < ActiveRecord::Base
  belongs_to :user
  belongs_to :workcode

  set_field_names :workcode_id =>'勤務区分',
    :request_date =>'届出月日',
    :start_time_h =>'勤務開始時間(時間)',
    :start_time_m =>'勤務開始時間(分)',
    :end_time_h =>'勤務終了時間(時間)',
    :end_time_m =>'勤務終了時間(分)',
    :overtime_start_time_h =>'残業開始時間(時間)',
    :overtime_start_time_m =>'残業開始時間(分)',
    :overtime_end_time_h =>'残業終了時間(時間)',
    :overtime_end_time_m =>'残業終了時間(分)'

  #定数
  CONFIRM=[['未入力',1],['休日他',2],['承認待',3],['差戻し',4],['◆',5]].freeze
  FCONFIRM=[['未入力',1],['承認待',3]].freeze

  def self.find_month(start_month_date,end_month_date)
    find(:all,
         :include => [:workcode],
         :conditions => ["input_date >=? AND input_date <= ?",
           start_month_date,end_month_date],
           :order => "input_date")
  end

  def self.find_month_m(start_month_date,end_month_date)
    find(:all,
         :include => [:workcode,:user],
         :conditions => ["input_date >=? AND input_date <= ?",
           start_month_date,end_month_date],
           :order => "input_date")
  end

  def self.vacation_sum(start_month_date,end_month_date)
    sum('workcodes.use_time',
        :conditions =>["input_date >= ? AND input_date <= ? ",start_month_date,end_month_date],
        :joins => "LEFT JOIN workcodes ON timecards.workcode_id = workcodes.id" )
  end

  def self.overtime_total_sum(start_month_date,end_month_date)
    sum('overtime_total',
        :conditions =>["input_date >= ? AND input_date <= ? AND confirmation_code = ?",
          start_month_date,end_month_date,5])
  end

  before_update :add_actual_time,:add_overtime_total

  def add_actual_time
      total_time=(self.end_time_h*60 + self.end_time_m) -(self.user.position.work_end_time_h*60 + self.user.position.work_end_time_m)
      if self.workcode_id==2||total_time>0
       self.actual_time=total_time 
      else 
       self.actual_time=0 
      end
  end

  def add_overtime_total
    self.overtime_total=self.overtime_total_h*60+self.overtime_total_m
  end

  validates_each :request_date do |model,attr,value|
    if value==nil && model.workcode_id ==3
      model.errors.add(attr,"を入力して下さい")
    elsif value != nil&&(model.workcode_id==1||model.workcode_id==2||model.workcode_id==4||model.workcode_id==5)
      model.errors.add(attr,"は入力しないで下さい")
    end
  end

  validates_numericality_of :start_time_h,:start_time_m,:end_time_h,:end_time_m,:overtime_start_time_h,:overtime_start_time_m,:overtime_end_time_h,:overtime_end_time_m,:overtime_total_h,:overtime_total_m
  validates_inclusion_of :start_time_h,:end_time_h,:overtime_start_time_h,:overtime_end_time_h,:overtime_total_h,:in =>0..23
  validates_inclusion_of :start_time_m,:end_time_m,:overtime_start_time_m,:overtime_end_time_m,:overtime_total_m,:in =>0..59

end
