class OldTimecard < ActiveRecord::Base
  belongs_to :user
  belongs_to :workcode

  set_field_names :workcode_id =>'勤務区分',
    :request_date =>'届出月日',
    :start_time_h =>'勤務開始時間(時間)',
    :start_time_m =>'勤務開始時間(分)',
    :end_time_h =>'勤務終了時間(時間)',
    :end_time_m =>'勤務終了時間(分)',
    :overtime_start_time_h =>'残業開始時間(時間)',
    :overtime_start_time_m =>'残業開始時間(分)',
    :overtime_end_time_h =>'残業開始時間(時間)',
    :overtime_end_time_m =>'残業開始時間(分)'

  #定数
  CONFIRM=[['未入力',1],['休日他',2],['承認待',3],['差戻し',4],['◆',5]].freeze

  def self.find_month(start_month_date,next_month_first)
    find(:all,
         :conditions => ["input_date >=? AND input_date < ?",
           start_month_date,next_month_first],
           :order => "input_date")
  end

  def self.find_month_confirm(start_month_date,next_month_first,confirm)
    find(:all,
         :conditions => ["input_date >=? AND input_date < ? AND confirmation_code = ?",
           start_month_date,next_month_first,confirm],
           :order => "input_date")
  end

  def self.find_month_m(start_month_date,next_month_first)
    find(:all,
         :conditions => ["input_date >=? AND input_date < ?",
           start_month_date,next_month_first],
           :order => "input_date")
  end

  def self.vacation_sum(user_id,start_month_date,next_month_first)
    find_by_sql(["SELECT user_id,SUM(workcodes.use_time) AS vac_sum
                  FROM old_timecards
                  LEFT JOIN workcodes
                  ON old_timecards.workcode_id = workcodes.id
                  WHERE
                  old_timecards.user_id = ?
                  AND
                  input_date >= ?
                  AND
                  input_date <? GROUP BY user_id",
                  user_id,start_month_date,next_month_first]).first
  end

  def self.overtime_total_sum(user_id,start_month_date,next_month_first)
    find_by_sql(["SELECT old_timecards.user_id,SUM(old_timecards.overtime_total) AS total_sum
                FROM old_timecards
                WHERE
                old_timecards.user_id = ?
                AND
                old_timecards.input_date >= ?
                AND
                old_timecards.input_date <?
                AND
                old_timecards.confirmation_code =?
                GROUP BY
                old_timecards.user_id",
                user_id,start_month_date,next_month_first,5]).first
  end
 
  validates_each :request_date do |model,attr,value|
    if value==nil && model.workcode_id ==3
      model.errors.add(attr,"を入力して下さい")
    elsif value != nil&&(model.workcode_id==1||model.workcode_id==2||model.workcode_id==4||model.workcode_id==5)
      model.errors.add(attr,"は入力しないで下さい")
    end
  end

  validates_numericality_of :start_time_h,:start_time_m,:end_time_h,:end_time_m,:overtime_start_time_h,:overtime_start_time_m,:overtime_end_time_h,:overtime_end_time_m,:overtime_total_h,:overtime_total_m
  validates_inclusion_of :start_time_h,:end_time_h,:overtime_start_time_h,:overtime_end_time_h,:overtime_total_h,:in =>0..23
  validates_inclusion_of :start_time_m,:end_time_m,:overtime_start_time_m,:overtime_end_time_m,:overtime_total_m,:in =>0..59

end
