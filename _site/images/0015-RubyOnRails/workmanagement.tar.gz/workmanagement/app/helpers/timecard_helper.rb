module TimecardHelper
end
