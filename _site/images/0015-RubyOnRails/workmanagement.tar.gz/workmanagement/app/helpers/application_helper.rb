# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper

  def const_display(const,sec_code)
    return const.rassoc(sec_code)[0]
  end
 
  def wday_kanji(w_day)
    w_days=[]
    w_days = %w(日 月 火 水 木 金 土)
    return w_days[w_day]
  end

end
