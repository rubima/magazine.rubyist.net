module VacationHelper
end
