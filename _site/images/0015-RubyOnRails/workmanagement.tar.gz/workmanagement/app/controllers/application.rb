# Filters added to this controller will be run for all controllers in the application.
# Likewise, all the methods added will be available for all controllers.
require_dependency "login_system" 
class ApplicationController < ActionController::Base
  include LoginSystem
  model :user

  before_filter :configure_charsets
  after_filter :fix_unicode_for_safari

  protected
  def configure_charsets
    @headers["Content-Type"] = "text/html; charset=utf-8"
  end

  def fix_unicode_for_safari
    user_agent = @request.env['HTTP_USER_AGENT']
    if @headers['Content-Type'] == 'text/html; charset=utf-8' and
      (user_agent.include? 'AppleWebKit' or user_agent.include? 'Konqueror') then
      @response.body.gsub!(/([^\x00-\xa0])/u) { |s| '&#x%x;' % $1.unpack('U')[0] }
    end
  end

  def access_limitation
    unless session[:user].id == 1
      redirect_to :controller =>'account',:action =>'login'
    end
  end

  def conv_start_month(date) 
    date.to_time.beginning_of_month.to_date
  end

  def conv_end_month(date)
    date.to_time.end_of_month.to_date
  end

  def conv_prev_month(date) 
    date.to_time.last_month.end_of_month.to_date
  end

  def conv_start_year(date)
    date.to_time.beginning_of_year.to_date
  end

  def conv_end_year(date)
    date.to_time.beginning_of_year.months_since(11).end_of_month.to_date
  end

end
