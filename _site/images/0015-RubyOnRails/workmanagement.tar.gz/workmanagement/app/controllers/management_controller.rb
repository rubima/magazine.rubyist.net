class ManagementController < ApplicationController
  before_filter :login_required,:access_limitation
  verify :method =>"post",
    :only =>[:update,:multi_update,:through_user_month_list,:through_date_user_list,:section_user_list,:note_update],
    :redirect_to =>{:action =>"index"}

  layout  'scaffold'

  def index
    select_timecard_pages(3)
    @workcodes=Workcode.find_all
    @timecard= nil
  end

  def list
    @timecards=session[:timecards]
    session[:timecards]=nil
  end

  def edit
    ref=request.env['HTTP_REFERER'].to_s.split(/\//)
    session[:back_action]=ref[4].to_s
    @timecard = Timecard.find(params[:id])
  end

  def update
    @timecard = Timecard.find(params[:id])
    @timecard.update_attributes(params[:timecard]) 
    if @timecard.save
      flash[:notice]='出勤表を更新しました'
      case session[:back_action]
      when 'user_month_list'
        return redirect_to :action =>'user_month_list', :id => @timecard.user
      when 'date_user_list'
        return redirect_to :action =>'date_user_list',:year =>@timecard.input_date.year,:month =>@timecard.input_date.month,:day =>@timecard.input_date.day
      else
        return redirect_to :action =>'index'
      end
    else
      render :action =>'edit'
    end
  end

  def multi_update
    unless params[:timecard].nil?
      catch (:timecard_valid) do
        params[:timecard].each do |key,value|
          @timecard = Timecard.find(key)
          @timecard.update_attributes(value)
          throw :timecard_valid unless @timecard.valid?
        end
        #        Timecard.update(params[:timecard].keys,params[:timecard].values)
        @timecards=Timecard.find(:all,
                                 :conditions =>["id IN (?)",params[:timecard].keys])
        session[:timecards]=@timecards
        flash[:notice]='出勤表を更新しました'
        return redirect_to :action =>'list'
      end
      select_timecard_pages(3)
      @workcodes=Workcode.find_all
      render :action =>'index'
    else
      redirect_to :action =>'index'
    end
  end

  def through_date_user_list
    redirect_to :action =>'date_user_list',:year => params[:date][:year],:month => params[:date][:month], :day => params[:date][:day]
  end

  def date_user_list
    @workcodes=Workcode.find_all
    @timecard_pages,@timecards = paginate(:timecard,
                                          :order =>'input_date',
                                          :include => [:workcode],
                                          :conditions => ["input_date= ?",Date.new(params[:year].to_i,params[:month].to_i,params[:day].to_i)])
  end

  def through_user_month_list
    redirect_to :action =>'user_month_list',:id =>params[:user][:id]
  end

  def user_month_list
    @workcodes=Workcode.find_all
    @user=User.find(params[:id])
    @timecards = @user.timecards.find_month_m(conv_start_month(session[:currentdate]),
                                              conv_end_month(session[:currentdate]))
    @total_time_view= @user.timecards.overtime_total_sum(conv_start_month(session[:currentdate]),
                              conv_end_month(session[:currentdate]))
    @vacation=@user.vacations.find_by_year(session[:currentdate].year)
    @previous_month_sum= 
      @user.timecards.vacation_sum(conv_start_year(session[:currentdate]),
                                   conv_prev_month(session[:currentdate]))
    @current_month_sum=
      @user.timecards.vacation_sum(conv_start_month(session[:currentdate]),
                                   conv_end_month(session[:currentdate]))
    @note=@user.notes.find_or_create_by_year_and_month(session[:currentdate].year,
                                                       session[:currentdate].month)
  end

  def note_update
    @note = Note.find(params[:id])
    @note.comment=params[:note][:comment]
    if @note.save
      flash[:notice]='備考欄を更新しました'
      redirect_to :back
    else
      @workcodes=Workcode.find_all
      @user=User.find(params[:id])
      @timecards = @user.timecards.find_month_m(conv_start_month(session[:currentdate]),
                                                conv_end_month(session[:currentdate]))
      @total_time_view= @user.timecards.overtime_total_sum(conv_start_month(session[:currentdate]),
                                                           conv_end_month(session[:currentdate]))
      @vacation=@user.vacations.find_by_year(session[:currentdate].year)
      @previous_month_sum= 
        @user.timecards.vacation_sum(conv_start_year(session[:currentdate]),
                                     conv_prev_month(session[:currentdate]))
      @current_month_sum=
        @user.timecards.vacation_sum(conv_start_month(session[:currentdate]),
                                     conv_end_month(session[:currentdate]))
    end
  end

  def section_user_list
    session[:currentdate]=session[:nowdate]
    @users = User.find(:all, :conditions =>["section_code= ?",params[:user][:section_code]])
  end

  protected
  def select_timecard_pages(confirm_flag)
    @timecard_pages,  @timecards = paginate(:timecard,
                                            :order =>'input_date',
                                            :include =>[:workcode,:user],
                                            :conditions =>['input_date >= ? AND input_date <= ? AND confirmation_code = ? ',
                                              conv_start_month(session[:currentdate]),
                                              conv_end_month(session[:currentdate]),
                                              confirm_flag])
  end

end
