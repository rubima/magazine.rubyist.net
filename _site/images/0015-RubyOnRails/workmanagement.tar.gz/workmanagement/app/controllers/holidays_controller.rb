class HolidaysController < ApplicationController
  before_filter :login_required,:access_limitation
  verify :method =>"post",
    :only =>[:update,:confirm_update,:create,:confirm_create,:destroy,:confirm_destroy],
    :redirect_to =>{:action =>"index"}

  include HolidaysHelper

  def index
    list
    render :action => 'list'
  end

  def list
   @holiday_pages, @holidays = paginate :holidays, :per_page => 30, :order=>'holiday_date',
     :conditions =>['holiday_date>= ? AND holiday_date <= ?',conv_start_year(session[:currentdate]),conv_end_year(session[:currentdate])]
  end

  def show
    @holiday = Holiday.find(params[:id])
  end

  def new
    @holiday = Holiday.new
  end

  def confirm_create
    @holiday = Holiday.new(params[:holiday])
    render :action => 'new' unless @holiday.valid?
  end

  def create
    @holiday = Holiday.new(params[:holiday])
    if params[:btn_cancel]
      render :action => 'new'
    elsif @holiday.save
      flash[:notice] = localize(:model, 'holiday') + localize(:command, :successfully_created)
      redirect_to :action => 'list'
    else
      render :action => 'new'
    end
  end

  def edit
    @holiday = Holiday.find(params[:id])
  end

  def confirm_update
    @holiday = Holiday.new(params[:holiday])
    render :action => 'edit' unless @holiday.valid?
  end

  def update
    @holiday = Holiday.find(params[:id])
    if params[:btn_cancel]
      @holiday.attributes = params[:holiday]
      render :action => 'edit'
    elsif @holiday.update_attributes(params[:holiday])
      flash[:notice] = localize(:model, 'holiday') + localize(:command, :successfully_updated)
      redirect_to :action => 'show', :id => @holiday
    else
      render :action => 'edit'
    end
  end

  def confirm_destroy
    @holiday = Holiday.find(params[:id])
  end

  def destroy
    if params[:btn_cancel]
      redirect_to :action => 'list'
    else
      Holiday.find(params[:id]).destroy
      redirect_to :action => 'list'
    end
  end

  def previous_year
    session[:currentdate] = session[:currentdate].to_time.last_year.to_date
      redirect_to :action=>"list"
  end

  def next_year
    session[:currentdate] = session[:currentdate].to_time.next_year.to_date
      redirect_to :action=>"list"
  end

  def current_year
    session[:currentdate] = session[:nowdate]
    redirect_to :action=>"list"
  end

end
