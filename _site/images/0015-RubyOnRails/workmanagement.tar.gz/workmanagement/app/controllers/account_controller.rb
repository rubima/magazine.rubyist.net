class AccountController < ApplicationController
  before_filter :login_required, :except => [:login, :signup]
  before_filter :access_limitation, :except => [:login, :signup]
  verify :method =>"post",
    :only =>:destroy,
    :redirect_to =>{:action =>"index"}
  layout  'scaffold'

  def login
    case @request.method
    when :post
      if session[:user] = User.authenticate(params[:user_login], params[:user_password])
        flash['notice']  = "ログインしました"
        session[:nowdate] = Date.today
        session[:currentdate] = session[:nowdate]
        unless session[:user].id == 1
        redirect_back_or_default :controller => 'timecard', :action => 'index'
        else
        redirect_back_or_default :controller => 'menu', :action => 'index'
        end
      else
        flash.now['notice']  = "ログインに失敗しました"

        @login = params[:user_login]
      end
    end
  end

  def signup
    redirect_to :action => "login" and return unless User.count.zero? 

    @user = User.new(params[:user])
    @user.full_name="るびま"

    if @request.post? and @user.save
      session[:user] = User.authenticate(@user.login, params[:user][:password])
      flash['notice']  = "管理者ユーザを作成しました"
      session[:nowdate] = Date.today
      session[:currentdate] = session[:nowdate]
      session[:m_currentdate] = session[:nowdate]
      redirect_back_or_default :controller => 'menu',:action => 'index'
    end      
  end  

  def logout
    session[:user] = nil
  end

  def index
    redirect_to :action =>'list'
  end

  def list
    if session[:user].id==1
      @user_pages,@users = paginate(:user,
                                    :per_page =>25)
    else
      redirect_to :action => 'login'
    end
  end

  def show
    @user = User.find(params[:id])
  end

  def new
    begin
      @user = User.new(params[:user])
      if request.post? and @user.save
        flash[:notice] = 'ユーザを作成しました'
        redirect_to :action => 'list'
      end      
    rescue
      flash[:notice] = '存在しない日付です'
      redirect_to :action => 'new'
    end
  end

  def edit
    @user = User.find(params[:id])
    begin
      @user.attributes = params[:user]
      if request.post? and @user.save
        flash[:notice] = 'ユーザ情報を更新しました'
        redirect_to :action => 'show', :id => @user
      end      
    rescue
      flash[:notice] = '存在しない日付です'
      redirect_to :action => 'edit'
    end
    @user.password = @user.password_confirmation =  ''
  end

  def confirm_destroy
    @user = User.find(params[:id])
  end

  def destroy
    if params[:btn_cancel]
      redirect_to :action => 'list'
    else
      begin
        User.find(params[:id]).destroy
      rescue
        flash[:notice] = "管理者ユーザを削除することは出来ません"
      end
      redirect_to :action => 'list'
    end
  end

end

