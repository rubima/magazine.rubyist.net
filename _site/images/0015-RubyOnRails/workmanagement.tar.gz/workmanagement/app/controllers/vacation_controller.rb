class VacationController < ApplicationController
  before_filter :login_required,:access_limitation
 verify :method =>"post",:only =>[:update,:confirm_update,:create,:confirm_create],:redirect_to =>{:action =>"list"}

  def index
    list
    render :action =>'list'
  end

  def list
      @user_pages,@users = paginate :user,:per_page =>25,:order =>'section_code'
  end

  def user_vacation
    @user=User.find(:first,
                    :include =>:vacations,
                    :order =>'year',
                    :conditions =>["users.id =?",params[:id]])
    @vacations=@user.vacations
  end

  def show
    @vacation = Vacation.find(params[:id])
    @user= @vacation.user
  end

  def edit
    @vacation = Vacation.find(params[:id])
    @user= @vacation.user
  end

  def new
    @user = User.find(params[:id])
    @vacation = @user.vacations.build
  end

  def confirm_update
    @vacation = Vacation.find(params[:id])
    @user=@vacation.user
    @vacation.attributes = params[:vacation]
    render :action => 'edit' unless @vacation.valid?
  end

  def confirm_create
    @user = User.find(params[:id])
    @vacation = @user.vacations.build(params[:vacation])
#    @vacation.user_year=@user.id.to_s+params[:date][:year].to_s
    render :action => 'new' unless @vacation.valid?
  end

  def create
    @user = User.find(params[:id])
    @vacation = @user.vacations.build(params[:vacation])
    if params[:btn_cancel]
      render :action =>'new'
    elsif @vacation.save
      flash[:notice] = "年休日数を作成しました"
      redirect_to :action =>'user_vacation',:id =>@user
    else
      render :action =>'new'
    end
  end

  def update
    @vacation = Vacation.find(params[:id])
    @user=@vacation.user
    @vacation.user_id = @user.id
    if params[:btn_cancel]
      @vacation.attributes =params[:vacation]
      render :action =>'edit'
    elsif @vacation.update_attributes(params[:vacation])
      flash[:notice] = "年休日数を更新しました"
      redirect_to :action =>'show',:id =>@vacation
    else
      render :action =>'edit'
    end
  end

end
