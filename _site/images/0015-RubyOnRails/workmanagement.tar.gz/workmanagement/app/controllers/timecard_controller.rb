class TimecardController < ApplicationController
  before_filter :login_required
  verify :method =>"post",:only =>[:update,:note_update],
    :redirect_to =>{:controller => "account",:action =>"login"}

  def index
    select_timecards_and_sum
    @note=
      session[:user].notes.find_or_create_by_year_and_month(session[:currentdate].year,
                                                            session[:currentdate].month)
  end

  def edit
    @timecard = Timecard.find(params[:id])
  end

  def update
    @timecard = Timecard.find(params[:id])
    @timecard.update_attributes(params[:timecard]) 
    if @timecard.save
      flash[:notice]='出勤表を更新しました'
      redirect_to :action =>'index'
    else
      render :action =>'edit'
    end
  end

  def note_update
    @note = Note.find(params[:id])
    @note.comment=params[:note][:comment]
    if @note.save
      flash[:notice]='備考欄を更新しました'
      redirect_to :action => 'index'
    else
      select_timecards_and_sum
      render :action =>'index'
    end
  end

  def previous_month
    session[:currentdate] = session[:currentdate]<<1
    redirect_to :back
  end

  def next_month
    session[:currentdate] = session[:currentdate]>>1
    redirect_to :back
  end

  def current_month
    session[:currentdate] = session[:nowdate]
    redirect_to :back
  end

  protected
  def select_timecards_and_sum
    @timecards =
      session[:user].timecards.find_month(conv_start_month(session[:currentdate]),
                                          conv_end_month(session[:currentdate]))
    @total_time_view= 
      session[:user].timecards.overtime_total_sum(conv_start_month(session[:currentdate]),
                                                  conv_end_month(session[:currentdate]))
    @vacation=session[:user].vacations.find_by_year(session[:currentdate].year)
    @previous_month_sum=
      session[:user].timecards.vacation_sum(conv_start_year(session[:currentdate]),
                                            conv_prev_month(session[:currentdate]))
    @current_month_sum= 
      session[:user].timecards.vacation_sum(conv_start_month(session[:currentdate]),
                                            conv_end_month(session[:currentdate]))
  end

end
