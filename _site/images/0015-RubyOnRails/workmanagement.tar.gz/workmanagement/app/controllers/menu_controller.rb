class MenuController < ApplicationController
  before_filter :login_required,:access_limitation

  def index
  end

end
