class OldManagementController < ApplicationController
  before_filter :login_required,:access_limitation
  before_filter :session_nil,:only =>[:show,:edit,:r_index]
  verify :method =>"post",
    :only =>[:update,:multi_update,:through_user_month_list,:through_date_user_list,:section_user_list,:note_update],
    :redirect_to =>{:action =>"index"}

  layout  'scaffold'

  def index
    @old_timecard_pages,  @old_timecards = paginate(:old_timecard,
                                                    :order =>'input_date',
                                                    :include =>[:workcode,:user],
                                                    :conditions =>['input_date >= ? AND input_date < ? AND confirmation_code = ? ',
                                                      Date.new(session[:currentdate].year,session[:currentdate].month,1),
                                                      Date.new(session[:currentdate].year,session[:currentdate].month,1)>>1,
                                                      3])
    @workcodes=Workcode.find_all
    @old_timecard= nil
  end

  def show
    @old_timecard = OldTimecard.find(params[:id])
    @user=@old_timecard.user
  end

  def edit
    @old_timecard = OldTimecard.find(params[:id])
  end

  def update
    @old_timecard = OldTimecard.find(params[:id])
    @old_timecard.update_attributes(params[:old_timecard]) 
    if @old_timecard.save
      flash[:notice]='出勤表を更新しました'
      redirect_to :action =>'show', :id => @old_timecard
    else
      render :action =>'edit'
    end
  end

  def multi_update
    @old_timecards = OldTimecard.find_month_confirm(Date.new(session[:currentdate].year,session[:currentdate].month,1),
                                                    Date.new(session[:currentdate].year,session[:currentdate].month,1)>>1,
                                                   3)
    i = 0
    @old_timecards.each do |old_timecard|
      i = i + 1
      old_timecard.workcode_id=params['old_timecard_'+i.to_s+'_workcode_id']
      old_timecard.start_time_h=params['old_timecard_'+i.to_s+'_start_time_h']
      old_timecard.start_time_m=params['old_timecard_'+i.to_s+'_start_time_m']
      old_timecard.end_time_h=params['old_timecard_'+i.to_s+'_end_time_h']
      old_timecard.end_time_m=params['old_timecard_'+i.to_s+'_end_time_m']
      old_timecard.request_date=params['old_timecard_'+i.to_s+'_request_date']
      old_timecard.card_comment=params['old_timecard_'+i.to_s+'_card_comment']
      old_timecard.overtime_start_time_h=params['old_timecard_'+i.to_s+'_overtime_start_time_h']
      old_timecard.overtime_start_time_m=params['old_timecard_'+i.to_s+'_overtime_start_time_m']
      old_timecard.overtime_end_time_h=params['old_timecard_'+i.to_s+'_overtime_end_time_h']
      old_timecard.overtime_end_time_m=params['old_timecard_'+i.to_s+'_overtime_end_time_m']
      old_timecard.overtime_total_h=params['old_timecard_'+i.to_s+'_overtime_total_h']
      old_timecard.overtime_total_m=params['old_timecard_'+i.to_s+'_overtime_total_m']
      old_timecard.confirmation_code=params['old_timecard_'+i.to_s+'_confirmation_code']
      total_time =
        (params['old_timecard_'+i.to_s+'_end_time_h'].to_i*60+params['old_timecard_'+i.to_s+'_end_time_m'].to_i)-
        (old_timecard.user.position.work_end_time_h*60+old_timecard.user.position.work_end_time_m)
      if total_time>0
        old_timecard.actual_time=total_time
      else
        old_timecard.actual_time=0
      end
      old_timecard.overtime_total=params['old_timecard_'+i.to_s+'_overtime_total_h'].to_i*60+params['old_timecard_'+i.to_s+'_overtime_total_m'].to_i
      old_timecard.save
    end
    flash[:notice]='出勤表を更新しました'
    redirect_to :action =>'index'
  end

  def date_user_list
    unless session[:choice_date]
      session[:choice_date]={:year => params[:date][:year],:month => params[:date][:month],:day => params[:date][:day]}
    end
    @old_timecard_pages,@old_timecards = paginate(:old_timecard,
                                                  :order =>'input_date',
                                                  :include => [:workcode],
                                                  :conditions => ["input_date= ?",Date.new(session[:choice_date][:year].to_i,session[:choice_date][:month].to_i,session[:choice_date][:day].to_i)])
    @workcodes=Workcode.find_all
  end

  def user_month_list
    unless session[:choice_user]
      session[:choice_user]={:id => params[:user][:id]}
    end
    @user=User.find(session[:choice_user][:id])
    @start_month_first=Date.new(session[:currentdate].year,session[:currentdate].month,1)
    @next_month_first=Date.new(session[:currentdate].year,session[:currentdate].month,1)>>1
    @old_timecards = @user.old_timecards.find_month_m(@start_month_first,
                                                      @next_month_first)
    @total_time_view= OldTimecard.overtime_total_sum(@user.id,
                                                     @start_month_first,
                                                     @next_month_first)
    @vacation=@user.vacations.find_by_year(session[:currentdate].year)
    @previous_month_sum= 
      OldTimecard.vacation_sum(@user.id,
                               Date.new(session[:currentdate].year,1,1),
                               @start_month_first)
    @current_month_sum=
      OldTimecard.vacation_sum(@user.id,@start_month_first,
                               @next_month_first)
    if @previous_month_sum.nil?
      @previous_month_sum ={'vac_sum' => 0,'user_id' => @user.id }
      if @previous_month_sum[:vac_sum].nil?
        @previous_month_sum[:vac_sum]=0
      end
    end
    if @current_month_sum.nil?
      @current_month_sum ={'vac_sum' => 0,'user_id' => @user.id }
      if @current_month_sum[:vac_sum].nil?
        @current_month_sum[:vac_sum]=0
      end
    end
    @note=@user.notes.find_or_create_by_year_and_month(session[:currentdate].year,
                                                       session[:currentdate].month)
    @workcodes=Workcode.find_all
  end

  def note_update
    @note = Note.find(params[:id])
    @note.comment=params[:note][:comment]
    if @note.save
      flash[:notice]='備考欄を更新しました'
      redirect_to :back
    else
      @workcodes=Workcode.find_all
      @user=User.find(params[:id])
      @start_month_first=Date.new(session[:currentdate].year,session[:currentdate].month,1)
      @next_month_first=Date.new(session[:currentdate].year,session[:currentdate].month,1)>>1
      @old_timecards = OldTimecard.find_month_m(@user.id,@start_month_first,
                                                @next_month_first)
      @total_time_view= OldTimecard.overtime_total_sum(@user.id,@start_month_first,
                                                       @next_month_first)
      @vacation=@user.vacations.find_by_year(session[:currentdate].year)
      @previous_month_sum= 
        OldTimecard.vacation_sum(@user.id,
                                 Date.new(session[:currentdate].year,1,1),
                                 @start_month_first)
      @current_month_sum=
        OldTimecard.vacation_sum(@user.id,@start_month_first,@next_month_first)
      if @previous_month_sum.nil?
        @previous_month_sum ={'vac_sum' => 0,'user_id' => @user.id }
        if @previous_month_sum[:vac_sum].nil?
          @previous_month_sum[:vac_sum]=0
        end
      end
      if @current_month_sum.nil?
        @current_month_sum ={'vac_sum' => 0,'user_id' => @user.id }
        if @current_month_sum[:vac_sum].nil?
          @current_month_sum[:vac_sum]=0
        end
      end
    end
  end

  def section_user_list
    session[:currentdate]=session[:nowdate]
    @users = User.find(:all, :conditions =>["section_code= ?",params[:user][:section_code]])
  end

  def r_index
    redirect_to :action =>'index'
  end


  protected
  def session_nil
    session[:choice_user]=nil
    session[:choice_date]=nil
  end

end
