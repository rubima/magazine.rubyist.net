class OldTimecardController < ApplicationController
  before_filter :login_required
  verify :method =>"post",:only =>[:update,:note_update],
    :redirect_to =>{:controller => "account",:action =>"login"}

  def index
    select_old_timecards_and_sum
    @note=
      session[:user].notes.find_or_create_by_year_and_month(session[:currentdate].year,
                                                            session[:currentdate].month)
  end

  def edit
    @old_timecard = OldTimecard.find(params[:id])
  end

  def update
    @old_timecard = OldTimecard.find(params[:id])
    unless params[:old_timecard][:workcode_id]==1
      @old_timecard.confirmation_code =3
    end
    @old_timecard.workcode_id = params[:old_timecard][:workcode_id]
    @old_timecard.start_time_h =params[:old_timecard][:start_time_h]
    @old_timecard.start_time_m =params[:old_timecard][:start_time_m]
    @old_timecard.end_time_h = params[:old_timecard][:end_time_h]
    @old_timecard.end_time_m = params[:old_timecard][:end_time_m]
    @old_timecard.request_date = params[:old_timecard][:request_date]
    @old_timecard.card_comment= params[:old_timecard][:card_comment]
    total_time =
      (params[:old_timecard][:end_time_h].to_i*60+params[:old_timecard][:end_time_m].to_i)-
      (session[:user].position.work_end_time_h*60+session[:user].position.work_end_time_m)
    if total_time>0
      @old_timecard.overtime_start_time_h = session[:user].position.work_end_time_h
      @old_timecard.overtime_start_time_m = session[:user].position.work_end_time_m
      @old_timecard.overtime_end_time_h = params[:old_timecard][:end_time_h]
      @old_timecard.overtime_end_time_m = params[:old_timecard][:end_time_m]
      @old_timecard.actual_time=total_time
      @old_timecard.overtime_total=total_time
      @old_timecard.overtime_total_h=total_time/60
      @old_timecard.overtime_total_m=total_time%60
    else
      @old_timecard.overtime_start_time_h=0
      @old_timecard.overtime_start_time_m=0
      @old_timecard.overtime_end_time_h=0
      @old_timecard.overtime_end_time_m=0
      @old_timecard.actual_time=0
      @old_timecard.overtime_total=0
      @old_timecard.overtime_total_h=0
      @old_timecard.overtime_total_m=0
    end
    if @old_timecard.save
      flash[:notice]='出勤表を更新しました'
      redirect_to :action =>'index'
    else
      render :action =>'edit'
    end
  end

  def note_update
    @note = Note.find(params[:id])
    @note.comment=params[:note][:comment]
    if @note.save
      flash[:notice]='備考欄を更新しました'
      redirect_to :action => 'index'
    else
      select_old_timecards_and_sum
      render :action =>'index'
    end
  end

  def previous_month
    session[:currentdate] = session[:currentdate]<<1
    redirect_to :back
  end

  def next_month
    session[:currentdate] = session[:currentdate]>>1
    redirect_to :back
  end

  def current_month
    session[:currentdate] = session[:nowdate]
    redirect_to :back
  end

  protected
  def select_old_timecards_and_sum
    @start_month_first=Date.new(session[:currentdate].year,session[:currentdate].month,1)
    @next_month_first=Date.new(session[:currentdate].year,session[:currentdate].month,1)>>1
    @old_timecards =
      session[:user].old_timecards.find_month(@start_month_first,
                                          @next_month_first)
    @previous_old_timecards =
      session[:user].old_timecards.find_month(Date.new(session[:currentdate].year,1,1),
                                          @start_month_first)
    @old_timecards_confirm =
      session[:user].old_timecards.find_month_confirm(@start_month_first,
                                          @next_month_first,5)
    @vacation=session[:user].vacations.find_by_year(session[:currentdate].year)
    @previous_month_sum=@vacation.yearly_vacation - vacation_sum(@previous_old_timecards)
    @current_month_sum=vacation_sum(@old_timecards)
    @overtime_total_view=overtime_total_sum(@old_timecards_confirm)
  end

  protected
  def vacation_sum(array)
    vacation=0
    array.each do |array|
      unless array.workcode.use_time==nil
        vacation=vacation+array.workcode.use_time
      end
    end
    return vacation
  end

  protected
  def overtime_total_sum(array)
    overtime_total=0
    array.each do |array|
        overtime_total=overtime_total+array.overtime_total
    end
    return overtime_total
  end

end
