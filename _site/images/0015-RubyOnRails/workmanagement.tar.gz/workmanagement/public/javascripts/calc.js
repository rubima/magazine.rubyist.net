function work_time_set(workcode,start_h,start_m,end_h,end_m,req_date,comment,u_start_h,u_start_m,u_end_h,u_end_m){
  if (workcode.valu==1||workcode.value==4||workcode.value==5){
    start_h.value="0";
    start_m.value="0";
    end_h.value="0";
    end_m.value="0";
    req_date.value="";
    comment.value="";
  }
  else if(workcode.value==2){
    start_h.value= u_start_h;
    start_m.value= u_start_m;
    end_h.value= u_end_h;
    end_m.value= u_end_m;
    req_date.value="";
    comment.value="";
  }
  else if (workcode.value==3){
    start_h.value="0";
    start_m.value="0";
    end_h.value="0";
    end_m.value="0";
    req_date.value='入力要';
    comment.value="";
    alert('yyyy-mm-ddの形式で届出月日を入力して下さい');
  }
  else {
    start_h.value="0";
    start_m.value="0";
    end_h.value="0";
    end_m.value="0";
    req_date.value="";
    comment.value="";
  }
}
function add_overtime(end_h,end_m,o_start_h,o_start_m,o_end_h,o_end_m,total_h,total_m,u_end_h,u_end_m){
  end_time=parseInt(end_h.value*60) + parseInt(end_m.value);
  over_start_time=parseInt(u_end_h * 60) + parseInt(u_end_m);
  total_time=parseInt(end_time)-parseInt(over_start_time);
  if (total_time>0){
    o_start_h.value = u_end_h;
    o_start_m.value = u_end_m;
    o_end_h.value = end_h.value;
    o_end_m.value = end_m.value;
    total_h.value = parseInt(total_time/60);
    total_m.value = parseInt(total_time%60);
  }
  else{
    o_start_h.value = "0";
    o_start_m.value = "0";
    o_end_m.value = "0";
    o_end_h.value = "0";
    total_h.value = "0";
    total_m.value = "0";
  }
}
function total_calc(total_h,total_m,total){
  total_time=parseInt(total_h.value * 60) + parseInt(total_m.value);
  total.value = parseInt(total_time);
}
