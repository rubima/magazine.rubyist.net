require File.dirname(__FILE__) + '/../test_helper'

class PositionTest < Test::Unit::TestCase
  fixtures :positions

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
