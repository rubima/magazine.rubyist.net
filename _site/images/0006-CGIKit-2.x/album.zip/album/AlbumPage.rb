require 'UploadPage'
require 'util'


class AlbumPage < CGIKit::Component
  
  include AlbumUtility
  
  attr_accessor :i
  
  def init
    init_utility
  end
  
  def css
    resource_manager.url('album.css')
  end
  
  def images
    begin
      get_entries(ymd2csvpath)
    rescue Exception
      []
    end
  end
  
  def img_path
    resource_manager.url(@i[0])
  end
  
  def comment
    @i[1]
  end
  
  def set_ymd(album_page, time)    
    album_page.year = time.year.to_s
    album_page.month = "%02d" % time.month
    album_page.day = "%02d" % time.day
  end
  
  
  
  def show_today
    a = page(AlbumPage)    
    set_ymd(a, Time.now)
    
    a
  end
  
  
  def show_next_month
    a = page(AlbumPage)    
    set_ymd(a, next_month)
    
    a
  end
  
  def show_next_day
    a = page(AlbumPage)    
    set_ymd(a, next_day)
    
    a
  end
  
  def show_prev_month
    a = page(AlbumPage)    
    set_ymd(a, prev_month)
    
    a
  end
  
  def show_prev_day
    a = page(AlbumPage)    
    set_ymd(a, prev_day)
    
    a
  end
  
  def upload
    if application.baseurl == ''
      '/upload.cgi'
    else
      File.join(File.dirname(application.baseurl), 'upload.cgi')
    end
  end
  
end
