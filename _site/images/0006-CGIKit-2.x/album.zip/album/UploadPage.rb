require 'util'
require 'kconv'

class UploadPage < CGIKit::Component
  
  include AlbumUtility
  
  attr_accessor :file, :comment
  
  def date
    Time.now.to_s
  end
  
  def init
    init_utility
  end
  
  def valid_file?
    (@file.length < 1000000)
  end
  
  def save_file
    m = page(MessagePage)
    
    unless valid_file?
      m.message = '�w�肳�ꂽ�t�@�C���̓T�C�Y���傫�߂��܂��B'
      m.redirect = true
      return m
    end
    unless valid_date?
      m.message = '���t�����������ł��B'
      m.redirect = true
      return m
    end
    
    d = ymd2imagedir
    begin
      unless FileTest.directory?(d)
        Dir.mkdir(d)
      end
      imagepath = File.join(d, @file.path); 
      @file.write_to_file( imagepath, true )
      add_entry( imagepath.split(File::Separator)[1..-1].join(File::Separator), Kconv::tosjis(@comment), ymd2csvpath)
      m.message = '�ۑ��ɐ���'
    rescue Exception
      m.message = '�ۑ��Ɏ��s: ' + $! + ' --- '+  $!.backtrace.inspect
      return m
    end
    
    m
  end
    
end

