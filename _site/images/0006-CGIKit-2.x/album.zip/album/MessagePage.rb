require 'AlbumPage'

class MessagePage < CGIKit::Component
  attr_accessor :message
    
  def index_url
    File.join( File.dirname(application.baseurl), 'index.cgi' )
  end
  
end