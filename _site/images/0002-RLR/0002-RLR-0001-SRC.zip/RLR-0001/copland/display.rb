# Display�N���X�̎���

module RLR
  class Display
    attr_accessor :filter
  
    def print(*args)
      if( @filter )
        $stdout.print(@filter[*args])
      else
        $stdout.print(*args)
      end
    end
  end
end
