# Filter�N���X�̎���

module RLR
  class Filter
    def [](*args)
      args.join()
    end
  end

  class LabelFilter < Filter
    attr_accessor :label
    
    def [](*args)
      super("[", label, "] ", *args)
    end
  end
end
