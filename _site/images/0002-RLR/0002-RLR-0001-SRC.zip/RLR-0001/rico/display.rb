# Display�N���X�̎���

module RLR
  class Display
    def initialize(filter = nil)
      @filter = filter
    end
  
    def print(*args)
      if( @filter )
        $stdout.print(@filter[*args])
      else
        $stdout.print(*args)
      end
    end
  end
end
