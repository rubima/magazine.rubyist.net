# Filter�N���X�̎���

module RLR
  class Filter
    def [](*args)
      args.join()
    end
  end

  class LabelFilter < Filter
    def initialize(label)
      @label = label
    end
    
    def [](*args)
      super("[", @label, "] ", *args)
    end
  end
end
