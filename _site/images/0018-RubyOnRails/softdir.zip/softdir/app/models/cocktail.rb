class Cocktail < ActiveRecord::Base

  def self.recipe_items
    find_by_sql(
      "xquery 
        for $recipe in db2-fn:xmlcolumn('COCKTAILS.RECIPE') 
        order by fn:abs($recipe//@number) 
        return <Recipe> {$recipe//@number,$recipe//recipename/text()} </Recipe>" )
  end

  def self.ingredient_to_recipe(id)
    rs = find_by_sql([
      "select * from cocktails 
        where xmlexists('$r/Recipe[@number = \"?\" ]' 
                passing COCKTAILS.RECIPE as \"r\")" ,id.to_i ])
    return rs[0]
  end

  def self.validate_recipe?(id)
    rs = find_by_sql([
      "select xmlvalidate(recipe according to xmlschema id xsr.recipe) from cocktails 
        where id = ?",id.to_i ])
    return rs[0]
  end

  def self.ingredient_items
    find_by_sql(
      "xquery 
        let $ingnames := fn:distinct-values(db2-fn:xmlcolumn('COCKTAILS.RECIPE')//ingredient/name/text()) 
        for $ing in $ingnames 
        order by $ing 
        return <Ingredient>{$ing ,<Recipes>{ 
          for $recipe in db2-fn:xmlcolumn('COCKTAILS.RECIPE')[//ingredient/name = $ing] 
          return <Recipe> {$recipe//@number, $recipe//recipename/text()}</Recipe> } </Recipes> }</Ingredient>" )
  end

end
