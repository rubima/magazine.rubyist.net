# Filters added to this controller will be run for all controllers in the application.
# Likewise, all the methods added will be available for all controllers.
require 'rexml/document'

# REXMLをincludeすれば、"REXML::"のプレフィックスを省略できる。
include REXML

class ApplicationController < ActionController::Base
  before_filter :specification_encode
  
  def specification_encode
    @headers["Content-Type"] = "text/html; charset=UTF-8"
  end

end