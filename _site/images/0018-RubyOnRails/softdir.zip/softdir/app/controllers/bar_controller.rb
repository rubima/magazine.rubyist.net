class BarController < ApplicationController
  
  def new
    @cocktail = Cocktail.new
  end

  def create
    y = params[:cocktail]
    y["recipe"] = recipe_create(params[:recipe_xml])
    @cocktail = Cocktail.new(y)
    if @cocktail.save
      flash[:notice] = 'Cocktail was successfully created.'
      redirect_to :action => 'index'
    else
      render :action => 'new'
    end
  end

  def index
    @cocktails = Cocktail.recipe_items
  end

  def ingredient
    @cocktails = Cocktail.ingredient_items
  end

  def show_by_ingredient
    @cocktail = Cocktail.ingredient_to_recipe(params[:id])
    render :template => 'bar/show'
  end

  def show
    @cocktail = Cocktail.find(params[:id])
  end
  
  def edit
    @cocktail = Cocktail.find(params[:id])
  end

  def update
    y = params[:cocktail]
    y["recipe"] = recipe_create(params[:recipe_xml])
    @cocktail = Cocktail.find(params[:id])
    if @cocktail.update_attributes(y)
      flash[:notice] = 'Cocktail was successfully updated.'
      redirect_to :action => 'show', :id => @cocktail
    else
      render :action => 'edit'
    end
  end

  def validate
    if Cocktail.validate_recipe?(params[:id])
      flash[:notice] = 'スキーマに準拠しています(^_^)v'
    else
      flash[:notice] = 'スキーマに準拠していません(T_T)'
    end
      render :layout => false
  end

  private
  
  def recipe_create(x)
    doc = REXML::Document.new()
    doc << REXML::XMLDecl.new('1.0','UTF-8')

    e0 =  REXML::Element.new('Recipe')
    e0.attributes['number'] = x['number']
    e0.add_element('recipename').add_text(x['recipename'])
    e0.add_element('style').add_text(x['style'])
    e0.add_element('glass').add_text(x['glass'])
    e1 = e0.add_element('ingredients')
    s = x['name'].values
    t = x['measure'].values
    u = x['unit'].values
    s.zip(t,u){|a,b,c|
      e2 = e1.add_element('ingredient')
      e2.add_element('name').add_text(a)
      e2.add_element('measure', {'unit' => c}).add_text(b)
    }
    e0.add_element('instruments').add_text(x['instruments'])
    e0.add_element('procedure').add_text(x['procedure'])
    x['taste'].each{ |key,value| e0.add_element('taste').add_text(value)}
    e0.add_element('strength').add_text(x['strength'])
    e0.add_element('photo').add_text(x['photo'])

    doc << e0
    return doc.to_s
  end

end
