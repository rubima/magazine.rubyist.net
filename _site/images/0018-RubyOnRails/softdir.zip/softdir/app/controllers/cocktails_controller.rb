class CocktailsController < ApplicationController
  def index
    list
    render :action => 'list'
  end

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  verify :method => :post, :only => [ :destroy, :create, :update ],
         :redirect_to => { :action => :list }

  def list
    @cocktail_pages, @cocktails = paginate :cocktails, :per_page => 10
  end

  def show
    @cocktail = Cocktail.find(params[:id])
  end

  def new
    @cocktail = Cocktail.new
  end

  def create
    @cocktail = Cocktail.new(params[:cocktail])
    if @cocktail.save
      flash[:notice] = 'Cocktail was successfully created.'
      redirect_to :action => 'list'
    else
      render :action => 'new'
    end
  end

  def edit
    @cocktail = Cocktail.find(params[:id])
  end

  def update
    @cocktail = Cocktail.find(params[:id])
    if @cocktail.update_attributes(params[:cocktail])
      flash[:notice] = 'Cocktail was successfully updated.'
      redirect_to :action => 'show', :id => @cocktail
    else
      render :action => 'edit'
    end
  end

  def destroy
    Cocktail.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
end
