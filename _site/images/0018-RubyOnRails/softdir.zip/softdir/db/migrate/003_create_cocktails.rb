class CreateCocktails < ActiveRecord::Migration
  def self.up
    create_table :cocktails do |t|
       t.column "recipe", :xml
       t.column "stop_flg", :boolean, :default => false, :null => false
       t.column "created_on", :datetime, :null => false
       t.column "updated_on", :datetime
    end
  end

  def self.down
    drop_table :cocktails
  end
end
