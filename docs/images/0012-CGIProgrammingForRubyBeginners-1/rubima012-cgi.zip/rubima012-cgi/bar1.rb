#!/usr/local/bin/ruby

print "Content-Type: text/html\n\n"
print "<html><head></head><body>OK?</body></html>"
