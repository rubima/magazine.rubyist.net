#!/usr/local/bin/ruby

f = open("C:/rubima012-cgi/message2.txt", "w")
f.write("hogehoge")
f.close
