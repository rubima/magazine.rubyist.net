#!/usr/local/bin/ruby

f = open("C:/rubima012-cgi/message.txt")
s = f.read
f.close
print s

