module Registration
  class MainPage < CGIKit::Component
  end
end