module Registration
  
  class ThanksPage < CGIKit::Component
    
    attr_accessor :name
        
  end
  
end
