require 'uconv'
require 'kconv'

module CGIKit
  
class Application
  class << self  
    attr_accessor :precede_iconv_as_rexml_encoding_module
  end
  self.precede_iconv_as_rexml_encoding_module = true 
end  
  
class DynamicElement
  def encode_string( string, encoding )
    Kconv.kconv(string, encoding)
  end
end

end
