require 'fcgi'

module CGIKit::Adapter

  class FastCGI
    # request = cgi
    def run( request, response )
      headers = request.env_table
      form_values = Hash.new([])
      request.params.each do |key, value|
        form_values[key] = value.list
      end

      ckrequest  = CGIKit::Request.new(headers, form_values)

      if block_given?
        response = yield(ckrequest)
      end

      print response.header
      print response.to_s
    end
  end

end
