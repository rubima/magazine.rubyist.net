files = ['CKErrorPage.html', 'CKErrorPage.ckd']
site = config('site-ruby')
files.each do |file|
  content = open(file).read
  dir = File.join(site, 'cgikit', 'components', 'CKErrorPage')
  path = File.join(dir, file)
  puts "install #{file} #{dir}"
  File.open(path, 'w') do |f|
    f.write(content)
  end
end
