module CGIKit::Project

  class ComponentTemplate < Template

    def template_template_en
      str = <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>#@name</title>
</head>
<body>

</body>
</html>
EOF
      Uconv.euctou8(str)
    end

    def script_template_en
      <<EOF
module #{project_name}

  class #@name < CGIKit::Component

    def init
      # put initialization code here
    end

  end

end
EOF
    end

  end

end
