module CGIKit::Project

  class SessionTemplate < Template

    def template_en
      <<EOF
module #{@project.name}

  class Session < CGIKit::Session

    def init
      # put initialization code here
    end

  end

end
EOF
    end

  end

end

