module CGIKit::Project

  class ApplicationTemplate < Template

    def template_en
      <<EOF
module #{@project.name}

  class Application < CGIKit::Application

    def init
      # put initialization code here
    end

  end

end
EOF
    end

  end

end

