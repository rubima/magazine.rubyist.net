module CGIKit::Project

  class DirectActionTemplate < Template

    def template_en
      <<EOF
module #{@project.name}

  class DirectAction < CGIKit::DirectAction

    def default_action
      page(application.main)
    end

  end

end
EOF
    end

  end

end

