module CGIKit::Project

  class ComponentTemplate < Template

    def template_template_ja
      <<EOF
<?xml version="1.0" encoding="EUC-JP"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="ja" xml:lang="ja">
<head>
<title>#@name</title>
</head>
<body>

</body>
</html>
EOF
    end

    def script_template_ja
      <<EOF
module #{project_name}

  class #@name < CGIKit::Component

    def init
      # �����˽���������ɤ򵭽Ҥ��ޤ�
    end

  end

end
EOF
    end

  end

end
