module Registration

  class Application < CGIKit::Application

    def init
      # put initialization code here
    end

  end

end
