module Registration

  class DirectAction < CGIKit::DirectAction

    def default_action
      page(application.main)
    end

  end

end
