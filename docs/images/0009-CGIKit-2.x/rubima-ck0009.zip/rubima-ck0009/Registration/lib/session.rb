module Registration

  class Session < CGIKit::Session

    def init
      # put initialization code here
    end

  end

end
