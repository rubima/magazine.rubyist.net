i = 1
while gets
  printf("  %02i| %s",i,$_)
  i += 1
end

