#! /usr/bin/ruby
# Miyakoサンプルスクリプト
# 「るびま」で掲載したRGSS用スクリプトのMiyako版(Author使用)

require 'miyako'

module Miyako

setTitle("るびまサンプル・Miyako版?")

class Spr
  def initialize(name, vp)
    @final = false
    @sp = Sprite.load(name)
    @sp.setViewPort(vp.x, vp.y, vp.w, vp.h)
    @sp.x = 0
    @sp.y = 0
    @sp.visible = true
    @stride = 8
  end
  
  def rect
    @sp.rect
  end
  
  def adjustment(n, min, max, size)
    if n < min
      min
    elsif n + size > max
      max - size
    else
      n
    end
  end
  
  def update
    br = @sp.rect
    sr = @sp.viewPort

    dx, dy = Input.triggerAmount

    @sp.x = adjustment(@sp.x + dx * @stride, sr.x, sr.w, br.w)
    @sp.y = adjustment(@sp.y + dy * @stride, sr.y, sr.h, br.h)
  end
end

class RubymaSample
  include Author

  class Scene_main < Script
    def initialize(n)
      super
      @sp = Spr.new("ruby.png", Rect.new(0, 0, 640, 480))
    end
    
    def update
      return nil if Input::quit? || Input::pushedEscape? || Input.pushed?(Input::BTN2)
      @sp.update()
      return @now
    end
    
  end
end

rs = RubymaSample.new
rs.run("main")

end
