#! /usr/bin/ruby
# Miyakoサンプル ボタン押下

require 'miyako'

module Miyako

	class RubymaTest
		include Author
		
		class Scene_first < Script
				def update
					return nil if Input.pushed?(Input::BTN1)
					return @now
				end
		end
		
	end

	rt = RubymaTest.new
	rt.run("first")

end
