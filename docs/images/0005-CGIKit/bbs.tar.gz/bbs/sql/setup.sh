#!/bin/sh

set -ex

dir=`dirname $0`
pg_dump -U postgres bbs > $dir/bbs.dump || :
dropdb -U postgres bbs || :
createdb -U postgres bbs
psql -U postgres bbs -c "\d" \
| awk '/table/ {print $1}' \
| xargs --no-run-if-empty -n 1 \
    sh -c 'psql -U postgres bbs -c "drop table $0"'
psql -U postgres bbs < $dir/create.sql > /dev/null
psql -U postgres bbs < $dir/insert.sql > /dev/null
