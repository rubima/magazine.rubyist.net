class BBS
  class BBSRecord < TapKit::GenericRecord
    def self.connect(model)
      @@tap = TapKit::Application.new(model)
#      @@tap.log_options[:sql] = true
    end
  end
end
