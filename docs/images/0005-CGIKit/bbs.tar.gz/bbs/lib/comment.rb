include TapKit
class BBS
  class Comment < BBSRecord
    def self.max_comment_no(thread_no)
      qualifier = Qualifier.format("thread_no == #{thread_no}")
      fetchspec = AggregateSpec.new("Comment", qualifier)
      fetchspec.add("max_id", "comment_no", AggregateSpec::MAX)
      return @@tap.create_editing_context.fetch(fetchspec)[0]['max_id'].to_i
    end

    def self.create
      @@tap.create_editing_context.create('Comment')
    end

    def insert
      @editing_context.save
    end
  end
end
