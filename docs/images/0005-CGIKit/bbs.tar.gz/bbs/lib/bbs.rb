class BBS < CKApplication
  def initialize
    super
  end
end
