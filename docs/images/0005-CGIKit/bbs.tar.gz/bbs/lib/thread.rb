include TapKit
class BBS
  class Thread < BBSRecord
    def self.list(count = 20)
      qualifier = Qualifier.format('')
      sort = SortOrdering.new('thread_no', SortOrdering::DESC)
      fetchspec = FetchSpec.new('Thread', qualifier, [sort])
      fetchspec.limit = count
      return @@tap.create_editing_context.fetch(fetchspec)
    end

    def self.get_by_no(thread_no)
      qualifier = Qualifier.format("thread_no == #{thread_no}")
      fetchspec = FetchSpec.new('Thread', qualifier)
      return @@tap.create_editing_context.fetch(fetchspec)[0]
    end

    def self.create
      @@tap.create_editing_context.create('Thread')
    end

    def insert
      @editing_context.save
    end

    def comment_list
      qualifier = Qualifier.format("thread_no == #{self.thread_no}")
#      sort = SortOrdering.new('comments.comment_no', SortOrdering::DESC)
#      fetchspec = FetchSpec.new('Thread', qualifier, [sort])
      fetchspec = FetchSpec.new('Thread', qualifier)
      return @@tap.create_editing_context.fetch(fetchspec)[0].comments
    end
  end
end
