class BBS
  class ThreadPage < CKComponent
    attr_accessor :thread_no
    def init
      @thread_no = Integer(request.form_value('thread_no'))
    end

    def pre_action
      thread = Thread.get_by_no(@thread_no)
      @thread_title = thread.title
      @thread_content = thread.contents
      @thread_e_mail = "mailto:#{CKUtilities::escape_html(thread.e_mail)}"
      @thread_date = thread.date
      @thread_register = thread.register
      @comment_list = thread.comment_list
    end

    def comment_email
      "mailto:#{CKUtilities::escape_html(@comment.e_mail)}"
    end

    def regist
      @error_msg = check
      unless @error_msg
        comment = Comment.create
        comment.register = @register
        comment.e_mail = @e_mail
        comment.contents = @content
        comment.date = Time.now
        comment.thread_no = @thread_no
        comment.comment_no = Comment.max_comment_no(@thread_no) + 1
        comment.insert
        next_page = page('ThreadPage')
        next_page.thread_no = @thread_no
        return next_page
      end
    end

    private

    def check
      error = []
      if @register.nil? || @register.empty?
        error << '̾�������Ϥ���Ƥ��ޤ���'
      end
      if @content.nil? || @content.empty?
        error << '���Ƥ����Ϥ���Ƥ��ޤ���'
      end
      if error.empty?
        return nil
      else
        return error.join('<br>')
      end
    end
  end
end
