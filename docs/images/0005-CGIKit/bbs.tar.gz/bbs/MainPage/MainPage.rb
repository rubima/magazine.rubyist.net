class BBS
  class MainPage < CKComponent
    def init
      @thread_list = Thread.list
    end

    def thread_query
      {'thread_no' => @thread.thread_no}
    end

    def tr_style
      if (@index % 2) == 1 then
        "background-color: #dddddd;"
      else
        "background-color: #eeeeee;"
      end
    end
  end
end
