class BBS
  class EditPage < CKComponent
    def regist
      @error_msg = check
      unless @error_msg
        thread = Thread.create
        thread.title = @title
        thread.register = @register
        thread.e_mail = @e_mail
        thread.contents = @content
        thread.date = Time.now
        thread.insert
        return page('MainPage')
      end
    end

    private

    def check
      error = []
      if @title.nil? || @title.empty?
        error << '�����ȥ뤬���Ϥ���Ƥ��ޤ���'
      end
      if @register.nil? || @register.empty?
        error << '̾�������Ϥ���Ƥ��ޤ���'
      end
      if error.empty?
        return nil
      else
        return error.join('<br>')
      end
    end
  end
end
