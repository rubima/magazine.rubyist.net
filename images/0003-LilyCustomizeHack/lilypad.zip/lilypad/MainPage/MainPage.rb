require 'fileutils'

class MainPage < CKComponent
  def init
    env = Hash.new

    File::open("./lily.cfg","r"){|f|
      f.read.each_line do |line|
        item = line.chomp.split(/\s+/)
        key = item.shift
        env[key] = item.join(' ')
      end
    }
    
    @datadir = env['datadir']
    @file_extension = env['file_extension'].split(/ /)
    @flavour = env['default_flavour']
    if env['url'] == ""
      @root_url = "http://#{request.server_name()}#{request.script_name()}"
    else
      @root_url = env['url']
    end

  end

  def update
    filename = Time.now.strftime("%Y%m%d%H%M%S")
  
    FileUtils.mkdir_p("#{@datadir}/#{@entry_path}")
    File.open("log/#{@entry_path}/#{filename}.#{@extension}",'w'){|f|
      f.puts @title
      f.print @body
    }
    
    @url = "#{@root_url}/#{@entry_path}/#{filename}.html"
  end
end
