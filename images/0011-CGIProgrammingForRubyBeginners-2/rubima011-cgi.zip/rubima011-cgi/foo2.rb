#!/usr/local/bin/ruby
 
print "Content-Type: text/html\n\n"
a = "Hello World"
print a
print "\n"
