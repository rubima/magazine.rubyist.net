#!/usr/local/bin/ruby

print "Content-Type: text/html\n\n"

print "<html>\n"
print "<head><title>foo5.rb</title></head>\n"
print "<body>\n"

a = rand 10
print "<img src=\"images/cat#{a}.jpg\">\n" 

print "</body>\n"
print "</html>\n"

