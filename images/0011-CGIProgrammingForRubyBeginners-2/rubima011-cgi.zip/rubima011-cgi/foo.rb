#!/usr/local/bin/ruby

print "Content-Type: text/html\n"
print "\n"
print 123
