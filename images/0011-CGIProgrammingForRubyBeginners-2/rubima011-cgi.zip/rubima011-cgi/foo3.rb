#!/usr/local/bin/ruby

print "Content-Type: text/html\n\n"

a = 1
b = 2
c = a + b
print "a = #{a} "
print "b = #{b} "
print "c = #{c} "
