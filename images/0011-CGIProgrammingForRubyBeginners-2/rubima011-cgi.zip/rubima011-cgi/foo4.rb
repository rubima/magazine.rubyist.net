#!/usr/local/bin/ruby

print "Content-Type: text/html\n\n"

print "<html>\n"
print "<head><title>foo4.rb</title></head>\n"
print "<body>\n"

print "<a href='foo2.rb'>foo2.rb</a>\n"

print "</body>\n"
print "</html>\n"
