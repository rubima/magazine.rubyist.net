print "123"
