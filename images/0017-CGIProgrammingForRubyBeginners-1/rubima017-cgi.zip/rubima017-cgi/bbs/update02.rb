#!/usr/local/bin/ruby

require "cgi"
require "kconv"

c = CGI.new
message = c["t"]

f = open("bbs.dat", "a") 
f.flock(File::LOCK_EX)
f.write(Kconv.toeuc(message) + "\n")
f.close

print "Content-type: text/html\n\n"

print <<EOF
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
   "http://www.w3.org/TR/html4/strict.dtd">
<html lang="ja">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
  <title>form</title>
</head>
<body>

�񤭹��ߤ��꤬�Ȥ��������ޤ�����
<a href="bbs01.rb">��ԷǼ��Ĥ�</a>

</body>
</html>
EOF
